# AveragedPerceptronPython
Clone of "A Good Part-of-Speech Tagger in about 200 Lines of Python" by Matthew Honnibal

## How to Play

Simply run the script `PerceptronTagger.py`, or:

```
tagger = PerceptronTagger()
tagger.train(...)
tagger.test(...)
```
